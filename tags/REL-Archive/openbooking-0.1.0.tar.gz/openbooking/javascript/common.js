
    /** JAVASCRIPT -- Common functions **/
    
function hide_element(id) {
	new Effect.Fade(id, {duration: 0.5});
    //document.getElementById(id).style.display = 'none';
}
